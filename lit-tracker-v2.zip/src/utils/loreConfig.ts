import React from 'react';
import { LoreType } from '../types';
import { Users, MapPin, Zap, Brain, Gem, BookOpen } from 'lucide-react';

export const LORE_TYPE_CONFIG: Record<LoreType, {
  label: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  borderColor: string;
  accentHex: string;
}> = {
  [LoreType.FACTION]: {
    label: 'Faction',
    icon: React.createElement(Users, { className: 'w-3.5 h-3.5' }),
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10',
    borderColor: 'border-blue-400/30',
    accentHex: '#60a5fa',
  },
  [LoreType.LOCATION]: {
    label: 'Location',
    icon: React.createElement(MapPin, { className: 'w-3.5 h-3.5' }),
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-400/10',
    borderColor: 'border-emerald-400/30',
    accentHex: '#34d399',
  },
  [LoreType.EVENT]: {
    label: 'Event',
    icon: React.createElement(Zap, { className: 'w-3.5 h-3.5' }),
    color: 'text-amber-400',
    bgColor: 'bg-amber-400/10',
    borderColor: 'border-amber-400/30',
    accentHex: '#fbbf24',
  },
  [LoreType.CONCEPT]: {
    label: 'Concept',
    icon: React.createElement(Brain, { className: 'w-3.5 h-3.5' }),
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10',
    borderColor: 'border-purple-400/30',
    accentHex: '#a78bfa',
  },
  [LoreType.ARTIFACT]: {
    label: 'Artifact',
    icon: React.createElement(Gem, { className: 'w-3.5 h-3.5' }),
    color: 'text-rose-400',
    bgColor: 'bg-rose-400/10',
    borderColor: 'border-rose-400/30',
    accentHex: '#fb7185',
  },
  [LoreType.RULE]: {
    label: 'Canon Rule',
    icon: React.createElement(BookOpen, { className: 'w-3.5 h-3.5' }),
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-400/10',
    borderColor: 'border-cyan-400/30',
    accentHex: '#22d3ee',
  },
};
