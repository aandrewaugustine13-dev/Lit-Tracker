import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { CharacterSlice, createCharacterSlice } from './characterSlice';
import { LoreSlice, createLoreSlice } from './loreSlice';
import { NavSlice, createNavSlice } from './navSlice';
import { InkSlice, createInkSlice } from './inkSlice';

// Combined store type
export type LitStore = CharacterSlice & LoreSlice & NavSlice & InkSlice;

export const useLitStore = create<LitStore>()(
  persist(
    (...a) => ({
      ...createCharacterSlice(...a),
      ...createLoreSlice(...a),
      ...createNavSlice(...a),
      ...createInkSlice(...a),
    }),
    {
      name: 'lit-tracker-v1',
      storage: createJSONStorage(() => localStorage),
      // Only persist data, not UI state.
      // Ink state persists itself to 'ink_tracker_data' for backward compat.
      partialize: (state) => ({
        characters: state.characters,
        relationships: state.relationships,
        loreEntries: state.loreEntries,
        projectName: state.projectName,
        activeModule: state.activeModule,
      }),
    }
  )
);

// Convenience selectors
export const useCharacters = () => useLitStore((s) => s.characters);
export const useLoreEntries = () => useLitStore((s) => s.loreEntries);
export const useActiveModule = () => useLitStore((s) => s.activeModule);

// Cross-reference selectors
export const useCharacterLoreEntries = (characterId: string) =>
  useLitStore((s) => {
    const char = s.characters.find(c => c.id === characterId);
    if (!char) return [];
    return s.loreEntries.filter(e => char.loreEntryIds.includes(e.id));
  });

export const useLoreEntryCharacters = (loreEntryId: string) =>
  useLitStore((s) => {
    const entry = s.loreEntries.find(e => e.id === loreEntryId);
    if (!entry) return [];
    return s.characters.filter(c => entry.characterIds.includes(c.id));
  });
