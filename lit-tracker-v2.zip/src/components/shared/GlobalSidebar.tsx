import React from 'react';
import { useLitStore } from '../../store';
import { ModuleId } from '../../types';
import {
  PenTool,
  Users,
  BookOpen,
  Flame,
  FolderOpen,
  Save,
  CloudOff,
  RefreshCcw,
  Settings,
  ChevronRight,
} from 'lucide-react';

const MODULE_CONFIG: { id: ModuleId; label: string; shortLabel: string; icon: React.ReactNode; accent: string }[] = [
  {
    id: 'ink',
    label: 'Storyboard',
    shortLabel: 'INK',
    icon: <PenTool size={20} />,
    accent: 'ember',
  },
  {
    id: 'characters',
    label: 'Characters',
    shortLabel: 'CHAR',
    icon: <Users size={20} />,
    accent: 'char',
  },
  {
    id: 'lore',
    label: 'World Bible',
    shortLabel: 'LORE',
    icon: <BookOpen size={20} />,
    accent: 'lore',
  },
];

const accentMap: Record<string, { active: string; indicator: string; glow: string }> = {
  ember: {
    active: 'text-ember-500 bg-ember-500/10',
    indicator: 'bg-ember-500',
    glow: 'shadow-ember-500/20',
  },
  char: {
    active: 'text-char-400 bg-char-500/10',
    indicator: 'bg-char-500',
    glow: 'shadow-char-500/20',
  },
  lore: {
    active: 'text-lore-400 bg-lore-500/10',
    indicator: 'bg-lore-500',
    glow: 'shadow-lore-500/20',
  },
};

const GlobalSidebar: React.FC = () => {
  const { activeModule, setActiveModule, syncStatus, projectName, characters, loreEntries } = useLitStore();

  return (
    <aside className="w-16 lg:w-56 bg-ink-900 border-r border-ink-700 h-screen flex flex-col flex-shrink-0 transition-all duration-300 z-50">
      {/* Brand */}
      <div className="h-16 flex items-center gap-3 px-3 lg:px-5 border-b border-ink-700 flex-shrink-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-ember-500 to-ember-400 flex items-center justify-center shadow-lg shadow-ember-500/20 flex-shrink-0">
          <Flame size={18} className="text-white" />
        </div>
        <div className="hidden lg:block min-w-0">
          <h1 className="text-base font-display font-bold text-steel-100 tracking-tight leading-tight truncate">
            LIT Tracker
          </h1>
          <p className="text-[9px] font-mono text-steel-600 uppercase tracking-[0.15em] truncate">
            {projectName}
          </p>
        </div>
      </div>

      {/* Module Navigation */}
      <nav className="flex-1 py-4 space-y-1 overflow-y-auto custom-scrollbar">
        {MODULE_CONFIG.map((mod) => {
          const isActive = activeModule === mod.id;
          const colors = accentMap[mod.accent];
          return (
            <button
              key={mod.id}
              onClick={() => setActiveModule(mod.id)}
              className={`
                w-full flex items-center gap-3 px-3 lg:px-5 py-3 transition-all duration-200 group relative
                ${isActive
                  ? `${colors.active} border-r-2 border-current`
                  : 'text-steel-500 hover:text-steel-200 hover:bg-ink-800'
                }
              `}
            >
              {/* Active indicator dot — mobile only */}
              {isActive && (
                <div className={`absolute left-1 top-1/2 -translate-y-1/2 w-1 h-6 rounded-full ${colors.indicator} lg:hidden`} />
              )}
              <span className="flex-shrink-0">{mod.icon}</span>
              <div className="hidden lg:flex flex-col items-start min-w-0">
                <span className="text-sm font-semibold truncate">{mod.label}</span>
                <span className="text-[9px] font-mono uppercase tracking-widest text-steel-600">
                  {mod.shortLabel}
                </span>
              </div>
              {isActive && (
                <ChevronRight size={14} className="ml-auto hidden lg:block opacity-60" />
              )}
            </button>
          );
        })}

        {/* Stats */}
        <div className="hidden lg:block pt-6 px-5 pb-2">
          <p className="text-[9px] font-mono font-bold text-steel-600 uppercase tracking-[0.2em] mb-3">
            Project Stats
          </p>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-steel-500">Characters</span>
              <span className="font-mono font-bold text-steel-300">{characters.length}</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-steel-500">Lore Entries</span>
              <span className="font-mono font-bold text-steel-300">{loreEntries.length}</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-3 lg:p-4 border-t border-ink-700 space-y-2">
        <div className="hidden lg:flex items-center gap-2 px-1">
          {syncStatus === 'saving' ? (
            <RefreshCcw size={11} className="text-ember-500 animate-spin" />
          ) : syncStatus === 'synced' ? (
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          ) : (
            <CloudOff size={11} className="text-steel-600" />
          )}
          <span className="text-[9px] font-mono text-steel-600 uppercase tracking-tighter">
            {syncStatus === 'saving' ? 'Saving...' : syncStatus === 'synced' ? 'Synced' : 'Local Only'}
          </span>
        </div>
      </div>
    </aside>
  );
};

export default GlobalSidebar;
